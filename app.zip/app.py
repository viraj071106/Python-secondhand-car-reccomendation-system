"""FastAPI service for the trained car recommendation ensemble."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

ROOT = Path(__file__).parent
BUNDLE_PATH = ROOT / "artifacts" / "model_bundle.joblib"
METRICS_PATH = ROOT / "artifacts" / "metrics.json"
DATA_PATH = ROOT / "artifacts" / "cleaned_data.csv"
app = FastAPI(title="Second-Hand Car Recommendation API", version="1.0.0")


class CarInput(BaseModel):
    features: dict[str, Any] = Field(..., description="Feature names must match /metadata")


class RecommendationRequest(BaseModel):
    budget: float | None = Field(default=None, gt=0)
    preferences: dict[str, Any] = Field(default_factory=dict)
    limit: int = Field(default=5, ge=1, le=50)


def bundle() -> dict[str, Any]:
    if not BUNDLE_PATH.exists():
        raise HTTPException(503, "Model is not trained. Run: python train.py --input data/car_dataset.csv")
    return joblib.load(BUNDLE_PATH)


def predict_frame(frame: pd.DataFrame) -> tuple[dict[str, np.ndarray], np.ndarray]:
    loaded = bundle()
    predictions = {name: model.predict(frame) for name, model in loaded["models"].items()}
    ensemble = sum(loaded["weights"][name] * predictions[name] for name in predictions)
    return predictions, ensemble


@app.get("/")
def root() -> dict[str, str]:
    return {"service": "second-hand-car-recommendation", "docs": "/docs", "health": "/health"}


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok" if BUNDLE_PATH.exists() else "not_trained"}


@app.get("/metadata")
def metadata() -> dict[str, Any]:
    loaded = bundle()
    return {"target": loaded["target"], "features": loaded["features"], "weights": loaded["weights"]}


@app.get("/metrics")
def metrics() -> dict[str, Any]:
    if not METRICS_PATH.exists():
        raise HTTPException(503, "Metrics are unavailable until training is complete.")
    return json.loads(METRICS_PATH.read_text())


@app.post("/predict")
def predict(payload: CarInput) -> dict[str, Any]:
    loaded = bundle()
    unknown = set(payload.features) - set(loaded["features"])
    if unknown:
        raise HTTPException(422, f"Unknown feature(s): {sorted(unknown)}")
    frame = pd.DataFrame([{feature: payload.features.get(feature) for feature in loaded["features"]}])
    predictions, ensemble = predict_frame(frame)
    return {
        "predicted_price": round(float(ensemble[0]), 2),
        "model_predictions": {name: round(float(value[0]), 2) for name, value in predictions.items()},
        "ensemble_weights": loaded["weights"],
    }


@app.post("/recommend")
def recommend(payload: RecommendationRequest) -> dict[str, Any]:
    if not DATA_PATH.exists():
        raise HTTPException(503, "Cleaned training data is unavailable until training is complete.")
    loaded = bundle()
    cars = pd.read_csv(DATA_PATH)
    filtered = cars.copy()
    target = loaded["target"]
    if payload.budget is not None:
        filtered = filtered[filtered[target] <= payload.budget]
    for key, value in payload.preferences.items():
        if key not in loaded["features"]:
            raise HTTPException(422, f"Unknown preference feature: {key}")
        if key in filtered.columns:
            filtered = filtered[filtered[key].astype(str).str.lower() == str(value).lower()]
    if filtered.empty:
        return {"recommendations": [], "message": "No cars match those filters."}
    features = filtered[loaded["features"]]
    predictions, ensemble = predict_frame(features)
    result = filtered.copy()
    result["ensemble_predicted_price"] = ensemble
    result["model_agreement"] = np.std(np.column_stack(list(predictions.values())), axis=1)
    result = result.sort_values(["model_agreement", "ensemble_predicted_price"]).head(payload.limit)
    return {"recommendations": result.replace({np.nan: None}).to_dict(orient="records")}
